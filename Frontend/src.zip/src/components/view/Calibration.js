import React from 'react';

class Calibration extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // empty
    };
  }


  render() {
    return (
      <div className="main-menu">
        <h1 className="menu-title"> Calibration </h1>
        
      </div>
    );
  }
}

export default Calibration;