export { default as MainMenu } from "./view/MainMenu";
export { default as CreateGraph } from "./view/CreateGraph";
export { default as test } from "./test";