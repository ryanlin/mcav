import React from 'react';

function test() {

  return (
    <div>
      <testButton />
    </div>
  )
};

export default test;